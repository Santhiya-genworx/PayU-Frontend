import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, FileText, Building2, Paperclip, Clock, Receipt, CheckCircle2, AlertTriangle, XCircle } from "lucide-react";
import type { InvoiceData, Decision } from "../../../types/invoice";
import InvoiceStatusBadge from "./status_badge";
import { formatCurrency } from "../../../lib/formatCurrency";
import InvoiceDetailsTab from "./details_tab";
import InvoiceVendorTab from "./vendor_tab";
import InvoiceFileTab from "./file_tab";
import InvoiceHistoryTab from "./history_tab";
import { getInvoiceDecision, approveInvoice, reviewInvoice, rejectInvoice } from "../services/documentService";

type Tab = "details" | "vendor" | "file" | "history";

const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
  { key: "details", label: "Details", icon: <FileText  className="w-3.5 h-3.5" /> },
  { key: "vendor",  label: "Vendor",  icon: <Building2 className="w-3.5 h-3.5" /> },
  { key: "file",    label: "File",    icon: <Paperclip className="w-3.5 h-3.5" /> },
  { key: "history", label: "History", icon: <Clock     className="w-3.5 h-3.5" /> },
];

// ── Confirm Approve Modal ─────────────────────────────────────────────────────
function ConfirmApproveModal({ invoiceId, onConfirm, onCancel }: {
  invoiceId: string; onConfirm: () => void; onCancel: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  const handleConfirm = async () => {
    setLoading(true); setError("");
    try { await approveInvoice(invoiceId); onConfirm(); }
    catch (err: any) { setError(err?.response?.data?.message ?? err?.message ?? "Approval failed."); setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden">
        <div className="px-5 py-5 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-sm font-bold text-gray-800 mb-1">Approve Invoice?</p>
          <p className="text-xs text-gray-500">
            Approving <span className="font-mono font-semibold text-gray-700">{invoiceId}</span> will allow payment processing.
          </p>
          {error && <p className="mt-2 text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2 w-full">{error}</p>}
        </div>
        <div className="px-5 pb-5 flex gap-2.5">
          <button onClick={onCancel} disabled={loading}
            className="flex-1 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button onClick={handleConfirm} disabled={loading}
            className="flex-1 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg disabled:opacity-60 disabled:cursor-not-allowed transition-colors">
            {loading ? "Approving…" : "Yes, Approve"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ── Review / Reject Confirm Modal ─────────────────────────────────────────────
// Backend handles email sending internally — no mail compose needed on frontend
function DecisionModal({ invoiceId, type, onConfirm, onCancel }: {
  invoiceId: string;
  type: "review" | "reject";
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const [decision, setDecision] = useState<Decision | null>(null);
  const [loading, setLoading]   = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]       = useState("");

  useEffect(() => {
    getInvoiceDecision(invoiceId)
      .then((res) => setDecision(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [invoiceId]);

  const handleConfirm = async () => {
    setSubmitting(true); setError("");
    try {
      if (type === "review") await reviewInvoice(invoiceId);
      else                   await rejectInvoice(invoiceId);
      onConfirm();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? err?.message ?? "Action failed.");
      setSubmitting(false);
    }
  };

  const cfg = type === "review"
    ? {
        icon:      <AlertTriangle className="w-6 h-6 text-amber-500" />,
        iconBg:    "bg-amber-50",
        label:     "Mark as Under Review?",
        sub:       "This will update the invoice status to reviewed and notify the vendor by email.",
        btnClass:  "bg-amber-500 hover:bg-amber-600 text-white",
        btnLabel:  "Yes, Mark Review",
        border:    "border-amber-200",
        bg:        "bg-amber-50",
        text:      "text-amber-700",
      }
    : {
        icon:      <XCircle className="w-6 h-6 text-red-500" />,
        iconBg:    "bg-red-50",
        label:     "Reject Invoice?",
        sub:       "This will reject the invoice and notify the vendor by email.",
        btnClass:  "bg-red-500 hover:bg-red-600 text-white",
        btnLabel:  "Yes, Reject",
        border:    "border-red-200",
        bg:        "bg-red-50",
        text:      "text-red-700",
      };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden">
        <div className="px-5 py-5 flex flex-col items-center text-center">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 ${cfg.iconBg}`}>
            {cfg.icon}
          </div>
          <p className="text-sm font-bold text-gray-800 mb-1">{cfg.label}</p>
          <p className="text-xs text-gray-500 leading-relaxed">{cfg.sub}</p>

          {/* Show AI decision details if available */}
          {loading ? (
            <div className="mt-3 animate-pulse w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full" />
          ) : decision?.command ? (
            <div className={`mt-3 w-full rounded-lg border ${cfg.border} ${cfg.bg} px-3 py-2.5 text-left`}>
              <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-1">AI Reason</p>
              <p className={`text-xs font-mono leading-relaxed ${cfg.text}`}>{decision.command}</p>
              {decision.confidence_score !== undefined && (
                <p className="text-[11px] text-gray-400 mt-1.5">
                  Confidence: <span className={`font-semibold ${cfg.text}`}>{Math.round(decision.confidence_score * 100)}%</span>
                </p>
              )}
            </div>
          ) : null}

          {/* Mail preview */}
          {!loading && decision?.mail_to && (
            <div className="mt-3 w-full bg-gray-50 rounded-lg border border-gray-100 px-3 py-2.5 text-left space-y-1">
              <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Email will be sent to</p>
              <p className="text-xs font-medium text-gray-700">{decision.mail_to}</p>
              {decision.mail_subject && (
                <p className="text-[11px] text-gray-400 truncate">Subject: {decision.mail_subject}</p>
              )}
            </div>
          )}

          {error && <p className="mt-2 text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2 w-full">{error}</p>}
        </div>

        <div className="px-5 pb-5 flex gap-2.5">
          <button onClick={onCancel} disabled={submitting}
            className="flex-1 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            Cancel
          </button>
          <button onClick={handleConfirm} disabled={submitting || loading}
            className={`flex-1 py-2 text-sm font-semibold rounded-lg disabled:opacity-60 disabled:cursor-not-allowed transition-colors ${cfg.btnClass}`}>
            {submitting ? "Processing…" : cfg.btnLabel}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ── Detail Panel ──────────────────────────────────────────────────────────────
export default function InvoiceDetailPanel({ invoice, onClose }: { invoice: InvoiceData; onClose: () => void }) {
  const [activeTab, setActiveTab]           = useState<Tab>("details");
  const [decision, setDecision]             = useState<Decision | null>(null);
  const [confirmApprove, setConfirmApprove] = useState(false);
  const [decisionModal, setDecisionModal]   = useState<"review" | "reject" | null>(null);

  useEffect(() => {
    getInvoiceDecision(invoice.invoice_id)
      .then((res) => { if (res) setDecision(res); })
      .catch(() => {});
  }, [invoice.invoice_id]);

  return (
    <>
      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.2 }}
        className="flex flex-col h-full bg-white">

        {/* Header */}
        <div className="bg-blue-600 px-5 py-4 shrink-0">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                <Receipt className="w-4 h-4 text-white" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white font-mono">{invoice.invoice_id}</h2>
                <p className="text-xs text-blue-200 mt-0.5 truncate max-w-48">{invoice.vendor.name}</p>
              </div>
            </div>
            <button onClick={onClose} className="w-7 h-7 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors shrink-0">
              <X className="w-3.5 h-3.5 text-white" />
            </button>
          </div>

          {/* Amount + status */}
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xl font-bold text-white tabular-nums">{formatCurrency(invoice.total_amount, invoice.currency_code)}</p>
              <p className="text-xs text-blue-200 mt-0.5">{invoice.invoice_date}</p>
            </div>
            <InvoiceStatusBadge status={invoice.status} />
          </div>

          {/* Action buttons — only when decision loaded */}
          {decision && (
            <div className="flex items-center gap-2">
              {decision.status === "approve" && (
                <button onClick={() => setConfirmApprove(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white text-emerald-700 hover:bg-emerald-50 text-xs font-semibold transition-colors">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                </button>
              )}
              {decision.status === "review" && (
                <button onClick={() => setDecisionModal("review")}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white text-amber-700 hover:bg-amber-50 text-xs font-semibold transition-colors">
                  <AlertTriangle className="w-3.5 h-3.5" /> Review
                </button>
              )}
              {decision.status === "reject" && (
                <button onClick={() => setDecisionModal("reject")}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white text-red-600 hover:bg-red-50 text-xs font-semibold transition-colors">
                  <XCircle className="w-3.5 h-3.5" /> Reject
                </button>
              )}
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100 px-2 overflow-x-auto shrink-0 bg-white">
          {tabs.map((tab) => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-3 text-xs font-semibold border-b-2 transition-all whitespace-nowrap mx-0.5
                ${activeTab === tab.key
                  ? "border-blue-500 text-blue-600 bg-blue-50/50 rounded-t-lg"
                  : "border-transparent text-gray-400 hover:text-gray-600 hover:bg-gray-50"}`}>
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto bg-gray-50/40">
          <div className="p-5">
            {activeTab === "details" && <InvoiceDetailsTab invoice={invoice} />}
            {activeTab === "vendor"  && <InvoiceVendorTab vendor={invoice.vendor} />}
            {activeTab === "file"    && <InvoiceFileTab fileUrl={invoice.file_url} />}
            {activeTab === "history" && <InvoiceHistoryTab invoiceId={invoice.invoice_id} />}
          </div>
        </div>
      </motion.div>

      {/* Modals */}
      <AnimatePresence>
        {confirmApprove && (
          <ConfirmApproveModal
            invoiceId={invoice.invoice_id}
            onConfirm={() => setConfirmApprove(false)}
            onCancel={() => setConfirmApprove(false)}
          />
        )}
        {decisionModal && (
          <DecisionModal
            invoiceId={invoice.invoice_id}
            type={decisionModal}
            onConfirm={() => setDecisionModal(null)}
            onCancel={() => setDecisionModal(null)}
          />
        )}
      </AnimatePresence>
    </>
  );
}