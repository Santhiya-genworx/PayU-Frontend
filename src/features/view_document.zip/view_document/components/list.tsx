import { useState, useMemo, useEffect, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Search, FileText, SlidersHorizontal, ChevronLeft, ChevronRight,
  Receipt, CheckCircle2, AlertTriangle, XCircle, X, Send, Mail,
} from "lucide-react";
import type { InvoiceData, Decision } from "../../../types/invoice";
import { formatCurrency } from "../../../lib/formatCurrency";
import { getInvoiceDecision, approveInvoice, reviewInvoice, rejectInvoice } from "../services/documentService";

// ── invoice status badge (actual invoice status) ──────────────────────────────
function InvStatusBadge({ status }: { status: "approved" | "pending" | "rejected" }) {
  const cfg = {
    approved: { bg: "bg-emerald-50", text: "text-emerald-700", dot: "bg-emerald-500", label: "Approved" },
    pending:  { bg: "bg-amber-50",   text: "text-amber-700",   dot: "bg-amber-400",   label: "Pending"  },
    reviewed:  { bg: "bg-blue-50",   text: "text-blue-700",   dot: "bg-blue-400",   label: "Reviewed"  },
    rejected: { bg: "bg-red-50",     text: "text-red-700",     dot: "bg-red-500",     label: "Rejected" },
  }[status];
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${cfg.bg} ${cfg.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}

// ── Confirm Approve Modal ─────────────────────────────────────────────────────
function ConfirmApproveModal({ invoiceId, onConfirm, onCancel }: {
  invoiceId: string; onConfirm: () => void; onCancel: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState("");

  const handleConfirm = async () => {
    setLoading(true); setError("");
    try { await approveInvoice(invoiceId); onConfirm(); }
    catch (err: any) { setError(err?.response?.data?.message ?? err?.message ?? "Approval failed."); setLoading(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl shadow-xl w-full max-w-sm overflow-hidden">
        <div className="px-5 py-5 flex flex-col items-center text-center">
          <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center mb-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-sm font-bold text-gray-800 mb-1">Approve Invoice?</p>
          <p className="text-xs text-gray-500">Approving <span className="font-mono font-semibold text-gray-700">{invoiceId}</span> will allow payment processing.</p>
          {error && <p className="mt-2 text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2 w-full">{error}</p>}
        </div>
        <div className="px-5 pb-5 flex items-center gap-2.5">
          <button onClick={onCancel} disabled={loading} className="flex-1 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Cancel</button>
          <button onClick={handleConfirm} disabled={loading} className="flex-1 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors disabled:opacity-60 disabled:cursor-not-allowed">
            {loading ? "Approving…" : "Yes, Approve"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ── Review / Reject Modal ─────────────────────────────────────────────────────
function DecisionDetailModal({ invoiceId, type, onClose, onStatusChange }: {
  invoiceId: string; type: "review" | "reject"; onClose: () => void;
  onStatusChange?: (invoiceId: string, newStatus: "reviewed" | "rejected") => void;
}) {
  const [decision, setDecision]           = useState<Decision | null>(null);
  const [loading, setLoading]             = useState(true);
  const [to, setTo]                       = useState("");
  const [subject, setSubject]             = useState("");
  const [body, setBody]                   = useState("");
  const [sending, setSending]             = useState(false);
  const [sent, setSent]                   = useState(false);
  const [sendError, setSendError]         = useState("");
  const [showMail, setShowMail]           = useState(false);

  useEffect(() => {
    getInvoiceDecision(invoiceId).then((res) => {
      setDecision(res);
      setTo(res?.mail_to ?? ""); setSubject(res?.mail_subject ?? ""); setBody(res?.mail_body ?? "");
    }).catch(console.error).finally(() => setLoading(false));
  }, [invoiceId]);

  const handleSend = async () => {
    setSending(true); setSendError("");
    try {
      // Call status API first, then send mail
      if (type === "review") await reviewInvoice(invoiceId);
      else                   await rejectInvoice(invoiceId);
      setSent(true);
      onStatusChange?.(invoiceId, type === "review" ? "reviewed" : "rejected");
      setTimeout(() => { setSent(false); setShowMail(false); onClose(); }, 1800);
    }
    catch (err: any) { setSendError(err?.response?.data?.message ?? err?.message ?? "Failed to send."); }
    finally { setSending(false); }
  };

  const cfg = type === "review"
    ? { icon: <AlertTriangle className="w-5 h-5 text-amber-500" />, label: "Needs Review", bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", iconBg: "bg-amber-50" }
    : { icon: <XCircle className="w-5 h-5 text-red-500" />,         label: "Rejected",     bg: "bg-red-50",   border: "border-red-200",   text: "text-red-700",   iconBg: "bg-red-50"   };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 16 }}
        className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${cfg.iconBg}`}>{cfg.icon}</div>
            <div><p className="text-sm font-bold text-gray-800">{cfg.label}</p><p className="text-[11px] text-gray-400 font-mono">{invoiceId}</p></div>
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-lg text-gray-400 hover:bg-gray-100 flex items-center justify-center transition-colors"><X className="w-4 h-4" /></button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-10">
              <div className="animate-spin w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full" />
            </div>
          ) : (
            <>
              <div className={`rounded-lg border ${cfg.border} ${cfg.bg} px-4 py-3 flex items-center justify-between`}>
                <div className="flex items-center gap-2">{cfg.icon}<p className={`text-sm font-semibold ${cfg.text}`}>{cfg.label}</p></div>
                {decision && <div className="text-right"><p className="text-[11px] text-gray-400">Confidence</p><p className={`text-sm font-bold ${cfg.text}`}>{Math.round((decision.confidence_score ?? 0) * 100)}%</p></div>}
              </div>

              {decision?.command && (
                <div className="bg-white rounded-lg border border-gray-100 overflow-hidden">
                  <div className="px-4 py-2 border-b border-gray-100 bg-gray-50"><p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Command</p></div>
                  <div className="px-4 py-3"><p className="text-xs text-gray-600 font-mono leading-relaxed whitespace-pre-wrap">{decision.command}</p></div>
                </div>
              )}

              {!showMail && (decision?.mail_to || decision?.mail_subject) && (
                <div className="bg-gray-50 rounded-lg border border-gray-100 px-4 py-3 space-y-1.5">
                  <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider mb-2">Mail Preview</p>
                  {decision?.mail_to      && <div className="flex gap-2 text-xs"><span className="text-gray-400 w-14 shrink-0">To:</span><span className="text-gray-700 font-medium">{decision.mail_to}</span></div>}
                  {decision?.mail_subject && <div className="flex gap-2 text-xs"><span className="text-gray-400 w-14 shrink-0">Subject:</span><span className="text-gray-700">{decision.mail_subject}</span></div>}
                </div>
              )}

              {showMail && (
                <div className="bg-white rounded-lg border border-gray-100 overflow-hidden">
                  <div className="px-4 py-2.5 border-b border-gray-100 bg-gray-50 flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-gray-400" />
                    <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Compose Mail</p>
                  </div>
                  <div className="px-4 py-3 space-y-3">
                    {[{ label: "To", value: to, setter: setTo }, { label: "Subject", value: subject, setter: setSubject }].map(({ label, value, setter }) => (
                      <div key={label}>
                        <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block mb-1">{label}</label>
                        <input value={value} onChange={(e) => setter(e.target.value)} className="w-full px-3 py-2 text-xs rounded-lg border border-gray-200 focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-400 transition-all" />
                      </div>
                    ))}
                    <div>
                      <label className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider block mb-1">Message</label>
                      <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={5} className="w-full px-3 py-2 text-xs rounded-lg border border-gray-200 focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-400 transition-all resize-none" />
                    </div>
                    {sendError && <p className="text-xs text-red-500 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{sendError}</p>}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="px-5 py-4 border-t border-gray-100 flex items-center gap-2.5 shrink-0">
          <button onClick={onClose} className="flex-1 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">Close</button>
          {!showMail ? (
            <button onClick={() => setShowMail(true)} className="flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
              <Mail className="w-3.5 h-3.5" /> Send Mail
            </button>
          ) : (
            <button onClick={handleSend} disabled={sending || sent || !to.trim()}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-semibold rounded-lg transition-all disabled:cursor-not-allowed ${sent ? "bg-emerald-600 text-white" : "bg-blue-600 hover:bg-blue-700 text-white disabled:bg-blue-300"}`}>
              <Send className="w-3.5 h-3.5" />
              {sending ? "Sending…" : sent ? "Sent!" : "Send Email"}
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}

// ── Main List ─────────────────────────────────────────────────────────────────
interface Props {
  invoices: InvoiceData[];
  selectedId: string | null;
  onSelect: (inv: InvoiceData) => void;
  onStatusChange?: (invoiceId: string, newStatus: "approved" | "reviewed" | "rejected") => void;
}

const PAGE_SIZE = 10;

export default function InvoiceList({ invoices, selectedId, onSelect, onStatusChange }: Props) {
  const [search, setSearch]             = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage]                 = useState(1);
  const [decisions, setDecisions]       = useState<Record<string, Decision>>({});
  const [confirmApprove, setConfirmApprove] = useState<string | null>(null);
  const [decisionModal, setDecisionModal]   = useState<{ id: string; type: "review" | "reject" } | null>(null);

  const filtered = useMemo(() => {
    setPage(1);
    return invoices.filter((inv) => {
      const matchSearch = !search || inv.invoice_id.toLowerCase().includes(search.toLowerCase()) || inv.vendor.name.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "all" || inv.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [invoices, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated  = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    paginated.forEach((inv) => {
      if (!decisions[inv.invoice_id]) {
        getInvoiceDecision(inv.invoice_id)
          .then((res) => { if (res) setDecisions((prev) => ({ ...prev, [inv.invoice_id]: res })); })
          .catch(() => {});
      }
    });
  }, [paginated.map(i => i.invoice_id).join(",")]);

  const handleApproveConfirmed = useCallback((invoiceId: string) => {
    setConfirmApprove(null);
    onStatusChange?.(invoiceId, "approved");
  }, [onStatusChange]);

  const statusConfig = [
    { key: "all",      label: "All",      count: invoices.length },
    { key: "approved", label: "Approved", count: invoices.filter(i => i.status === "approved").length },
    { key: "pending",  label: "Pending",  count: invoices.filter(i => i.status === "pending").length  },
    { key: "rejected", label: "Rejected", count: invoices.filter(i => i.status === "rejected").length },
  ];

  return (
    <>
      <div className="flex flex-col h-full">
        <div className="p-3 space-y-2.5 border-b border-gray-100 bg-gray-50/50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search invoices…"
              className="w-full pl-8 pr-3 py-2 text-xs bg-white rounded-lg border border-gray-200 focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-400 transition-all placeholder:text-gray-400" />
          </div>
          <div className="flex items-center gap-1">
            <SlidersHorizontal className="w-3 h-3 text-gray-400 mr-0.5 shrink-0" />
            {statusConfig.map((s) => (
              <button key={s.key} onClick={() => setStatusFilter(s.key)}
                className={`flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-md transition-all
                  ${statusFilter === s.key ? "bg-blue-600 text-white shadow-sm" : "bg-white text-gray-500 border border-gray-200 hover:bg-gray-50"}`}>
                {s.label}
                <span className={`text-[10px] px-1 rounded font-semibold ${statusFilter === s.key ? "bg-white/25 text-white" : "bg-gray-100 text-gray-400"}`}>{s.count}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 py-1.5 text-[11px] text-gray-400 border-b border-gray-100 bg-gray-50/30">
          {filtered.length} invoice{filtered.length !== 1 ? "s" : ""} · page {page}/{totalPages}
        </div>

        <div className="flex-1 overflow-y-auto">
          <AnimatePresence>
            {paginated.length === 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-16 text-gray-400">
                <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center mb-2"><FileText className="w-5 h-5 opacity-40" /></div>
                <p className="text-xs font-medium">No invoices found</p>
              </motion.div>
            )}
            {paginated.map((inv, idx) => {
              const dec = decisions[inv.invoice_id];
              const isSelected = selectedId === inv.invoice_id;
              return (
                <motion.div key={inv.invoice_id} layout initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ delay: idx * 0.025 }}
                  className={`border-b border-gray-50 transition-colors group ${isSelected ? "bg-blue-50 border-l-2 border-l-blue-500" : "hover:bg-gray-50/60"}`}>
                  <button onClick={() => onSelect(inv)} className="w-full text-left px-4 pt-3.5 pb-2">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 transition-colors ${isSelected ? "bg-blue-100" : "bg-gray-100 group-hover:bg-blue-50"}`}>
                          <Receipt className={`w-3.5 h-3.5 ${isSelected ? "text-blue-600" : "text-gray-400 group-hover:text-blue-500"}`} />
                        </div>
                        <span className="text-xs font-bold text-gray-800 font-mono truncate">{inv.invoice_id}</span>
                      </div>
                      {/* Always show actual invoice status */}
                      <InvStatusBadge status={inv.status} />
                    </div>
                    <p className="text-xs text-gray-500 mb-1.5 ml-9 truncate">{inv.vendor.name}</p>
                    <div className="flex items-center justify-between ml-9">
                      <span className="text-[11px] text-gray-400">{inv.invoice_date}</span>
                      <span className="text-xs font-bold text-gray-800">{formatCurrency(inv.total_amount, inv.currency_code)}</span>
                    </div>
                    {inv.po_id && (
                      <div className="ml-9 mt-1">
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-gray-100 text-gray-400">PO: {inv.po_id}</span>
                      </div>
                    )}
                  </button>

                  {/* Action buttons — only when decision exists */}
                  {dec && (
                    <div className="px-4 pb-3 ml-9 flex items-center gap-1.5">
                      {dec.status === "approve" && (
                        <button onClick={(e) => { e.stopPropagation(); setConfirmApprove(inv.invoice_id); }}
                          className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-md bg-emerald-600 hover:bg-emerald-700 text-white transition-colors">
                          <CheckCircle2 className="w-3 h-3" /> Approve
                        </button>
                      )}
                      {dec.status === "review" && (
                        <button onClick={(e) => { e.stopPropagation(); setDecisionModal({ id: inv.invoice_id, type: "review" }); }}
                          className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-md bg-amber-500 hover:bg-amber-600 text-white transition-colors">
                          <AlertTriangle className="w-3 h-3" /> Review
                        </button>
                      )}
                      {dec.status === "reject" && (
                        <button onClick={(e) => { e.stopPropagation(); setDecisionModal({ id: inv.invoice_id, type: "reject" }); }}
                          className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold rounded-md bg-red-500 hover:bg-red-600 text-white transition-colors">
                          <XCircle className="w-3 h-3" /> Reject
                        </button>
                      )}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-2.5 border-t border-gray-100 bg-gray-50/40">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-gray-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white text-gray-500 transition-all">
              <ChevronLeft className="w-3 h-3" /> Prev
            </button>
            <div className="flex items-center gap-0.5">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setPage(p)} className={`w-6 h-6 text-xs font-semibold rounded-md transition-all ${page === p ? "bg-blue-600 text-white" : "text-gray-400 hover:bg-gray-100"}`}>{p}</button>
              ))}
            </div>
            <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg border border-gray-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white text-gray-500 transition-all">
              Next <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {confirmApprove && (
          <ConfirmApproveModal invoiceId={confirmApprove} onConfirm={() => handleApproveConfirmed(confirmApprove)} onCancel={() => setConfirmApprove(null)} />
        )}
        {decisionModal && (
          <DecisionDetailModal invoiceId={decisionModal.id} type={decisionModal.type} onClose={() => setDecisionModal(null)} onStatusChange={onStatusChange} />
        )}
      </AnimatePresence>
    </>
  );
}