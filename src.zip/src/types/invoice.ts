import type { Vendor } from "./process";

export interface InvoiceItem {
  item_description: string;
  quantity?: number;
  unit_price?: number;
  total_price: number;
}

// ── Single invoice detail (used inside a matching group) ─────────────────────
export interface InvoiceDetail {
  invoice_id:    string;
  invoice_date:  string;
  due_date:      string;
  total_amount:  number;
  subtotal:      number;
  tax_amount:    number;
  currency_code: string;
  vendor?: {
    name:          string;
    email:         string;
    mobile_number: string;
    address:       string;
  } | null;
}

// ── Single PO detail (used inside a matching group) ──────────────────────────
export interface PODetail {
  po_id:        string;
  total_amount: number;
  currency_code: string;
  status:       string;
  ordered_date: string;
}

// ── InvoiceData now represents a MATCHING GROUP ──────────────────────────────
// Each row returned by getInvoiceMatchings() is one group that may contain
// multiple invoices and multiple POs matched together.
//
// For backwards-compat with filterInvoices() (single-invoice API), most
// fields are still optional so that the old per-invoice shape still compiles.
export interface InvoiceData {
  // ── Group-based matching fields (new schema) ─────────────────────────────
  group_id?:   number;          // auto-increment PK of invoice_matching row
  invoice_ids?: string[];       // all invoice_ids in the group
  po_ids?:      string[];       // all po_ids in the group

  // Enriched detail objects (populated by getInvoiceMatchings)
  invoices?:   InvoiceDetail[]; // full detail for each invoice in the group
  pos?:        PODetail[];      // full detail for each PO in the group

  // ── is_po_matched tri-state ───────────────────────────────────────────────
  // null  = still waiting for one or more POs to be uploaded
  // true  = all POs present; group was/is being matched by LLM
  // false = no POs referenced (invoice-only, no PO flow)
  is_po_matched: boolean | null;

  // ── Matching decision fields ──────────────────────────────────────────────
  matching_status?:  "pending" | "approved" | "reviewed" | "rejected";
  decision?:         "approve" | "review" | "reject" | null;
  confidence_score?: number | null;
  command?:          string | null;
  mail_to?:          string | null;
  mail_subject?:     string | null;
  mail_body?:        string | null;

  // ── Legacy / filterInvoices() single-invoice fields ───────────────────────
  // These are populated when consuming filterInvoices() (not matchings).
  // Kept optional so both code-paths compile without casting.
  invoice_id?:     string;
  vendor?:         Vendor;
  po_id?:          string | null;   // deprecated; use po_ids[]
  invoice_date?:   string;
  due_date?:       string;
  invoice_items?:  InvoiceItem[];
  currency_code?:  string;
  subtotal?:       number;
  tax_amount?:     number;
  discount_amount?: number;
  total_amount?:   number;
  file_url?:       string;
  status?:         "approved" | "pending" | "rejected" | "reviewed";
}

// ── Helpers to work with group data ──────────────────────────────────────────

/** Primary invoice in a group (first one, for display purposes) */
export function primaryInvoice(data: InvoiceData): InvoiceDetail | null {
  return data.invoices?.[0] ?? null;
}

/** Representative invoice_id for a group (first, or legacy single field) */
export function groupInvoiceId(data: InvoiceData): string {
  return data.invoice_ids?.[0] ?? data.invoice_id ?? "";
}

/** Representative amount for a group (sum across all invoices) */
export function groupTotalAmount(data: InvoiceData): number {
  if (data.invoices && data.invoices.length > 0) {
    return data.invoices.reduce((sum, inv) => sum + (inv.total_amount ?? 0), 0);
  }
  return data.total_amount ?? 0;
}

/** Representative currency for a group (first invoice's currency) */
export function groupCurrencyCode(data: InvoiceData): string {
  return data.invoices?.[0]?.currency_code ?? data.currency_code ?? "INR";
}

/** Representative date for a group (first invoice's date) */
export function groupInvoiceDate(data: InvoiceData): string {
  return data.invoices?.[0]?.invoice_date ?? data.invoice_date ?? "";
}

/** Representative vendor for a group (first invoice's vendor) */
export function groupVendorName(data: InvoiceData): string {
  return data.invoices?.[0]?.vendor?.name ?? data.vendor?.name ?? "";
}

/** Display label for po_ids array */
export function groupPoLabel(data: InvoiceData): string {
  if (data.po_ids && data.po_ids.length > 0) return data.po_ids.join(", ");
  if (data.po_id) return data.po_id;
  return "";
}

export interface Decision {
  status:           "approve" | "review" | "reject";
  confidence_score: number;
  command:          string;
  mail_to?:         string;
  mail_subject?:    string;
  mail_body?:       string;
}