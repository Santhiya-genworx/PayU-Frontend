import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./features/auth/pages/login";
import Dashboard from "./features/dashboard/pages/dashboard";
import ViewDocuments from "./features/view_document/pages/view_document";
import Invoices from "./features/view_document/pages/invoices";

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/documents" element={<ViewDocuments />} />
        <Route path="/invoices" element={<Invoices />}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;