import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { FileText, Receipt, Search, Sparkles, TrendingUp } from "lucide-react";
import type { InvoiceData } from "../../../types/invoice";
import { filterInvoices, getDocumentStats } from "../services/documentService";
import InvoiceSummaryCards from "../components/summary_cards";
import InvoiceList from "../components/list";
import InvoiceDetailPanel from "../components/detail_panel";
import { useDispatch, useSelector } from "react-redux";
import { type AppDispatch, type RootState } from "../../../app/store";
import { fetchUser } from "../../auth/slices/authSlice";
import Sidebar from "../../dashboard/components/sidebar";
import { Navigate } from "react-router-dom";

export default function Invoices() {
    const dispatch = useDispatch<AppDispatch>();
    const user = useSelector((state: RootState) => state.auth.user);
  const [invoices, setInvoices] = useState<InvoiceData[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const init = async () => { await dispatch(fetchUser());};
        init();
    const fetchData = async () => {
      try {
        const [invoiceData, statsData] = await Promise.all([
          filterInvoices(),
          getDocumentStats(),
        ]);
        setInvoices(invoiceData);
        setStats(statsData);
      } catch (error) {
        console.error("Failed to load invoices", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (!user) return <Navigate to="/" />;

  const initials = user.name.split(" ").map((n: string) => n[0]).join("").toUpperCase();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gray-50 gap-3">
        <div className="w-12 h-12 rounded-2xl bg-blue-100 flex items-center justify-center animate-pulse">
          <Receipt className="w-6 h-6 text-blue-600" />
        </div>
        <p className="text-sm font-medium text-gray-500">Loading invoices...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F7F8FC]">

      {/* Top Header Bar */}
      <header className="bg-white border-b border-gray-100 shadow-sm sticky top-0 z-30">
        <div className="max-w-400 mx-auto px-6 py-4 flex items-center justify-between">
            <button onClick={() => setSidebarOpen(true)} className="text-gray-600 hover:text-gray-900 text-xl transition-colors cursor-pointer">☰</button>
          <div className="flex items-center gap-4">
            {/* Icon + Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-linear-to-br from-blue-500 to-blue-700 flex items-center justify-center shadow-sm">
                <Receipt className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900 leading-tight">Invoices</h1>
                <p className="text-xs text-gray-400 leading-none mt-0.5">Manage and review all invoices</p>
              </div>
            </div>

            {/* Count pill */}
            <span className="flex items-center gap-1.5 text-xs font-bold text-blue-700 bg-blue-100 px-3 py-1 rounded-full">
              <FileText className="w-3.5 h-3.5" />
              {invoices.length} total
            </span>
          </div>

          {/* Right side info */}
          <div className="flex items-center gap-3 text-xs text-gray-400">
            <div className="flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-full font-semibold border border-emerald-100">
              <Sparkles className="w-3.5 h-3.5" />
              AI Processing Active
            </div>
            <div className="flex items-center gap-1.5 bg-gray-50 text-gray-500 px-3 py-1.5 rounded-full font-medium border border-gray-100">
              <TrendingUp className="w-3.5 h-3.5" />
              Live
            </div>
          </div>
        </div>
      </header>

      {/* Page Content */}
      <div className="max-w-400 mx-auto px-6 py-5 space-y-5">
        <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} user={{ ...user, initials }} />
        

        {/* Summary Cards */}
        {stats && <InvoiceSummaryCards stats={stats} />}

        {/* Main split layout */}
        <div className="flex gap-5 h-[calc(100vh-295px)] min-h-125">

          {/* Invoice List Panel */}
          <div className="w-105 shrink-0 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden flex flex-col">
            {/* Panel header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-linear-to-r from-blue-600 to-blue-700">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-blue-200" />
                <span className="text-sm font-bold text-white">Invoice List</span>
              </div>
              <span className="text-xs font-bold text-blue-200">{invoices.length} records</span>
            </div>

            <InvoiceList
              invoices={invoices}
              selectedId={selectedInvoice?.invoice_id ?? null}
              onSelect={(inv) =>
                setSelectedInvoice((prev) =>
                  prev?.invoice_id === inv.invoice_id ? null : inv
                )
              }
            />
          </div>

          {/* Detail / Empty Panel */}
          <div className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              {selectedInvoice ? (
                <motion.div
                  key={selectedInvoice.invoice_id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                  className="h-full bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
                >
                  <InvoiceDetailPanel
                    invoice={selectedInvoice}
                    onClose={() => setSelectedInvoice(null)}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col items-center justify-center bg-white rounded-2xl border border-gray-100 shadow-sm"
                >
                  {/* Decorative background rings */}
                  <div className="relative flex items-center justify-center mb-6">
                    <div className="absolute w-32 h-32 rounded-full bg-blue-50 opacity-60" />
                    <div className="absolute w-20 h-20 rounded-full bg-blue-100 opacity-60" />
                    <div className="relative w-16 h-16 rounded-2xl bg-linear-to-br from-blue-500 to-blue-700 flex items-center justify-center shadow-lg">
                      <FileText className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  <p className="text-base font-bold text-gray-700 mb-1">Select an invoice to view details</p>
                  <p className="text-sm text-gray-400">Click any invoice from the list on the left</p>

                  {/* Feature pills */}
                  <div className="flex flex-wrap items-center justify-center gap-2 mt-6 max-w-xs">
                    {["Invoice Details", "Vendor Info", "File Preview", "Upload History", "AI Result"].map((f) => (
                      <span key={f} className="text-xs font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                        {f}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>
      </div>
    </div>
  );
}