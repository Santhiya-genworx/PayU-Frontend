import { Building2, MapPin, Mail, Phone, FileCheck, Landmark, User, Globe } from "lucide-react";
import type { Vendor } from "../../../types/process";

export default function InvoiceVendorTab({ vendor }: { vendor: Vendor }) {
  const phone = vendor.mobile_number
    ? `${vendor.country_code} ${vendor.mobile_number}`
    : "";

  const sections = [
    {
      title: "Company Info",
      color: "from-violet-500 to-violet-600",
      items: [
        { icon: <Building2 className="w-4 h-4" />, label: "Company Name", value: vendor.name,    bg: "bg-violet-50", text: "text-violet-600" },
        { icon: <MapPin    className="w-4 h-4" />, label: "Address",      value: vendor.address, bg: "bg-violet-50", text: "text-violet-600" },
        { icon: <Globe     className="w-4 h-4" />, label: "Country",      value: vendor.country_code, bg: "bg-violet-50", text: "text-violet-600" },
      ].filter(i => i.value),
    },
    {
      title: "Contact",
      color: "from-sky-500 to-sky-600",
      items: [
        { icon: <Mail  className="w-4 h-4" />, label: "Email", value: vendor.email, bg: "bg-sky-50", text: "text-sky-600" },
        { icon: <Phone className="w-4 h-4" />, label: "Phone", value: phone,        bg: "bg-sky-50", text: "text-sky-600" },
      ].filter(i => i.value),
    },
    {
      title: "Tax & Compliance",
      color: "from-emerald-500 to-emerald-600",
      items: [
        { icon: <FileCheck className="w-4 h-4" />, label: "GST Number", value: vendor.gst_number, bg: "bg-emerald-50", text: "text-emerald-600" },
      ].filter(i => i.value),
    },
    {
      title: "Banking Details",
      color: "from-amber-500 to-amber-600",
      items: [
        { icon: <Landmark className="w-4 h-4" />, label: "Bank Name",       value: vendor.bank_name,            bg: "bg-amber-50", text: "text-amber-600" },
        { icon: <User     className="w-4 h-4" />, label: "Account Holder",  value: vendor.account_holder_name,  bg: "bg-amber-50", text: "text-amber-600" },
        { icon: <Landmark className="w-4 h-4" />, label: "Account Number",  value: vendor.account_number,       bg: "bg-amber-50", text: "text-amber-600" },
        { icon: <Landmark className="w-4 h-4" />, label: "IFSC Code",       value: vendor.ifsc_code,            bg: "bg-amber-50", text: "text-amber-600" },
      ].filter(i => i.value),
    },
  ];

  return (
    <div className="space-y-4">
      {/* Avatar card */}
      <div className="bg-linear-to-r from-violet-500 to-violet-700 rounded-2xl p-4 text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-xl font-bold">
            {vendor.name?.charAt(0) ?? "V"}
          </div>
          <div>
            <p className="font-bold text-lg leading-tight">{vendor.name}</p>
            <p className="text-xs text-white/75 mt-0.5">{vendor.email}</p>
          </div>
        </div>
      </div>

      {sections.map((section) =>
        section.items.length === 0 ? null : (
          <div key={section.title} className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm">
            <div className={`bg-linear-to-r ${section.color} px-4 py-2`}>
              <p className="text-xs font-bold text-white uppercase tracking-widest">{section.title}</p>
            </div>
            <div className="divide-y divide-gray-50">
              {section.items.map((item) => (
                <div key={item.label} className="flex items-start gap-3 px-4 py-3">
                  <div className={`w-7 h-7 rounded-lg ${item.bg} flex items-center justify-center shrink-0 mt-0.5 ${item.text}`}>
                    {item.icon}
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">{item.label}</p>
                    <p className="text-sm font-medium text-gray-800 break-all mt-0.5">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )
      )}
    </div>
  );
}