import { useState, useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, FileText, SlidersHorizontal, ChevronLeft, ChevronRight, Receipt } from "lucide-react";
import type { InvoiceData } from "../../../types/invoice";
import InvoiceStatusBadge from "./status_badge";
import { formatCurrency } from "../../../lib/formatCurrency";

interface Props {
  invoices: InvoiceData[];
  selectedId: string | null;
  onSelect: (inv: InvoiceData) => void;
}

const PAGE_SIZE = 10;

export default function InvoiceList({ invoices, selectedId, onSelect }: Props) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    setPage(1);
    return invoices.filter((inv) => {
      const matchSearch =
        !search ||
        inv.invoice_id.toLowerCase().includes(search.toLowerCase()) ||
        inv.vendor.name.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === "all" || inv.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [invoices, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const statusConfig = [
    { key: "all", label: "All", count: invoices.length },
    { key: "approved", label: "Approved", count: invoices.filter(i => i.status === "approved").length },
    { key: "pending", label: "Pending", count: invoices.filter(i => i.status === "pending").length },
    { key: "rejected", label: "Rejected", count: invoices.filter(i => i.status === "rejected").length },
  ];

  const filterActiveStyle: Record<string, string> = {
    all: "bg-blue-600 text-white shadow-sm",
    approved: "bg-emerald-500 text-white shadow-sm",
    pending: "bg-amber-500 text-white shadow-sm",
    rejected: "bg-red-500 text-white shadow-sm",
  };

  return (
    <div className="flex flex-col h-full">
      {/* Search */}
      <div className="p-4 space-y-3 border-b border-gray-100 bg-gray-50/60">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search invoices…"
            className="w-full pl-9 pr-3 py-2.5 text-sm bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-200 focus:border-blue-400 transition-all placeholder:text-gray-400 shadow-sm"
          />
        </div>

        {/* Status Filters */}
        <div className="flex items-center gap-1.5">
          <SlidersHorizontal className="w-3.5 h-3.5 text-gray-400 mr-0.5" />
          {statusConfig.map((s) => (
            <button
              key={s.key}
              onClick={() => setStatusFilter(s.key)}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                statusFilter === s.key
                  ? filterActiveStyle[s.key]
                  : "bg-white text-gray-500 border border-gray-200 hover:border-gray-300 hover:bg-gray-50"
              }`}
            >
              {s.label}
              <span className={`text-[10px] px-1 rounded-full font-bold ${statusFilter === s.key ? "bg-white/30 text-white" : "bg-gray-100 text-gray-500"}`}>
                {s.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Count */}
      <div className="px-4 py-2 text-xs text-gray-400 border-b border-gray-100 bg-gray-50/40">
        {filtered.length} invoice{filtered.length !== 1 ? "s" : ""} &middot; Page {page} of {totalPages}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        <AnimatePresence>
          {paginated.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-20 text-gray-400"
            >
              <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-3">
                <FileText className="w-7 h-7 opacity-50" />
              </div>
              <p className="text-sm font-medium">No invoices found</p>
              <p className="text-xs mt-1 text-gray-300">Try adjusting your filters</p>
            </motion.div>
          )}

          {paginated.map((inv, idx) => (
            <motion.button
              key={inv.invoice_id}
              layout
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ delay: idx * 0.03 }}
              onClick={() => onSelect(inv)}
              className={`w-full text-left px-4 py-3.5 border-b border-gray-100 transition-all group ${
                selectedId === inv.invoice_id
                  ? "bg-blue-50 border-l-2 border-l-blue-500 pl-3.5"
                  : "hover:bg-gray-50/80"
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                    selectedId === inv.invoice_id ? "bg-blue-100" : "bg-gray-100 group-hover:bg-blue-50"
                  }`}>
                    <Receipt className={`w-4 h-4 ${selectedId === inv.invoice_id ? "text-blue-600" : "text-gray-400 group-hover:text-blue-500"}`} />
                  </div>
                  <span className="text-sm font-bold text-gray-800 font-mono truncate">
                    {inv.invoice_id}
                  </span>
                </div>
                <InvoiceStatusBadge status={inv.status} />
              </div>

              <p className="text-sm text-gray-600 mb-2 ml-10">{inv.vendor.name}</p>

              <div className="flex items-center justify-between ml-10">
                <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-md">{inv.invoice_date}</span>
                <span className="text-sm font-bold text-gray-900">
                  {formatCurrency(inv.total_amount, inv.currency_code)}
                </span>
              </div>

              {inv.po_id && (
                <div className="ml-10 mt-1.5">
                  <span className="inline-block text-[10px] font-mono px-2 py-0.5 rounded-md bg-blue-50 text-blue-500 border border-blue-100">
                    PO: {inv.po_id}
                  </span>
                </div>
              )}
            </motion.button>
          ))}
        </AnimatePresence>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 bg-gray-50/50">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white hover:shadow-sm text-gray-600"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Prev
          </button>

          <div className="flex items-center gap-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={`w-7 h-7 text-xs font-bold rounded-lg transition-all ${
                  page === p
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-gray-500 hover:bg-gray-100"
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 transition-all disabled:opacity-40 disabled:cursor-not-allowed hover:bg-white hover:shadow-sm text-gray-600"
          >
            Next
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}