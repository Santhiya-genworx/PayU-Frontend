import { useEffect, useState } from "react";
import { CheckCircle2, AlertTriangle, XCircle, Shield, Send, Edit3, Bot, Sparkles, Mail } from "lucide-react";
import type { Decision } from "../../../types/invoice";
import { getInvoiceDecision } from "../services/documentService";

export default function InvoiceStatusTab({ invoiceId }: { invoiceId: string }) {
  const [decision, setDecision] = useState<Decision | null>(null);
  const [loading, setLoading] = useState(true);
  const [mailTo, setMailTo] = useState("");
  const [mailSubject, setMailSubject] = useState("");
  const [mailBody, setMailBody] = useState("");
  const [editing, setEditing] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    async function fetchDecision() {
      try {
        const res = await getInvoiceDecision(invoiceId);
        setDecision(res);
        setMailTo(res?.mail_to ?? "");
        setMailSubject(res?.mail_subject ?? "");
        setMailBody(res?.mail_body ?? "");
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    fetchDecision();
  }, [invoiceId]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-16">
        <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center mb-3 animate-pulse">
          <Bot className="w-6 h-6 text-emerald-500" />
        </div>
        <p className="text-sm text-gray-500">Fetching AI decision...</p>
      </div>
    );
  }

  if (!decision) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-gray-400">
        <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center mb-3">
          <Shield className="w-7 h-7 opacity-40" />
        </div>
        <p className="text-sm font-semibold text-gray-600">No AI decision yet</p>
        <p className="text-xs mt-1 text-gray-400">Run the LangGraph flow to see results</p>
      </div>
    );
  }

  const decisionConfig = {
    approve: {
      icon: <CheckCircle2 className="w-6 h-6" />,
      label: "Invoice Approved",
      sublabel: "Payment can be processed",
      gradient: "from-emerald-500 to-emerald-600",
      bg: "bg-emerald-50",
      border: "border-emerald-200",
      text: "text-emerald-700",
      badge: "bg-emerald-100 text-emerald-700",
      score: "text-emerald-600",
    },
    review: {
      icon: <AlertTriangle className="w-6 h-6" />,
      label: "Needs Review",
      sublabel: "Minor discrepancies found",
      gradient: "from-amber-500 to-amber-600",
      bg: "bg-amber-50",
      border: "border-amber-200",
      text: "text-amber-700",
      badge: "bg-amber-100 text-amber-700",
      score: "text-amber-600",
    },
    reject: {
      icon: <XCircle className="w-6 h-6" />,
      label: "Invoice Rejected",
      sublabel: "Major discrepancies detected",
      gradient: "from-red-500 to-red-600",
      bg: "bg-red-50",
      border: "border-red-200",
      text: "text-red-700",
      badge: "bg-red-100 text-red-700",
      score: "text-red-600",
    },
  };

  const cfg = decisionConfig[decision.status];
  const confidencePct = Math.round((decision.confidence_score ?? 0) * 100);

  const handleSend = () => {
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="space-y-5">
      {/* Decision Hero Card */}
      <div className={`rounded-2xl overflow-hidden border ${cfg.border}`}>
        <div className={`bg-linear-to-r ${cfg.gradient} p-4 flex items-center gap-3`}>
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
            {cfg.icon}
          </div>
          <div>
            <p className="text-base font-bold text-white">{cfg.label}</p>
            <p className="text-xs text-white/80">{cfg.sublabel}</p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-white/70" />
            <span className="text-sm font-bold text-white">{confidencePct}%</span>
          </div>
        </div>

        {/* Confidence bar */}
        <div className={`${cfg.bg} px-4 py-3`}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-gray-500">Confidence Score</span>
            <span className={`text-xs font-bold ${cfg.score}`}>{confidencePct}%</span>
          </div>
          <div className="h-2 bg-white rounded-full overflow-hidden border border-gray-200">
            <div
              className={`h-full bg-linear-to-r ${cfg.gradient} rounded-full transition-all duration-700`}
              style={{ width: `${confidencePct}%` }}
            />
          </div>
        </div>
      </div>

      {/* AI Command */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2.5 bg-gray-50 border-b border-gray-100">
          <Bot className="w-4 h-4 text-gray-500" />
          <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">AI Summary</span>
        </div>
        <div className="px-4 py-3">
          <p className="text-sm text-gray-700 leading-relaxed font-mono">{decision.command}</p>
        </div>
      </div>

      {/* Email section (only for review/reject) */}
      {decision.status !== "approve" && (
        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 bg-linear-to-r from-sky-50 to-blue-50 border-b border-sky-100">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-sky-600" />
              <span className="text-xs font-bold text-sky-700 uppercase tracking-wider">Vendor Notification Email</span>
            </div>
            <button
              onClick={() => setEditing(!editing)}
              className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg transition-all ${
                editing
                  ? "bg-blue-600 text-white"
                  : "bg-white border border-gray-200 text-gray-600 hover:border-blue-300 hover:text-blue-600"
              }`}
            >
              <Edit3 className="w-3 h-3" />
              {editing ? "Done" : "Edit"}
            </button>
          </div>

          <div className="p-4 space-y-3">
            <div>
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-1">To</label>
              <input
                value={mailTo}
                onChange={(e) => setMailTo(e.target.value)}
                disabled={!editing}
                className={`w-full px-3 py-2 text-sm rounded-lg border transition-all ${
                  editing
                    ? "border-blue-300 bg-blue-50/50 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    : "border-gray-100 bg-gray-50 text-gray-600"
                }`}
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Subject</label>
              <input
                value={mailSubject}
                onChange={(e) => setMailSubject(e.target.value)}
                disabled={!editing}
                className={`w-full px-3 py-2 text-sm rounded-lg border transition-all ${
                  editing
                    ? "border-blue-300 bg-blue-50/50 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    : "border-gray-100 bg-gray-50 text-gray-600"
                }`}
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-gray-400 uppercase tracking-wider block mb-1">Body</label>
              <textarea
                value={mailBody}
                onChange={(e) => setMailBody(e.target.value)}
                disabled={!editing}
                rows={6}
                className={`w-full px-3 py-2 text-sm rounded-lg border transition-all resize-none ${
                  editing
                    ? "border-blue-300 bg-blue-50/50 focus:outline-none focus:ring-2 focus:ring-blue-200"
                    : "border-gray-100 bg-gray-50 text-gray-600"
                }`}
              />
            </div>

            <button
              onClick={handleSend}
              className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all ${
                sent
                  ? "bg-emerald-500 text-white"
                  : "bg-linear-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800 shadow-sm hover:shadow"
              }`}
            >
              <Send className="w-4 h-4" />
              {sent ? "Email Sent!" : "Send Email to Vendor"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}