import { useState } from "react";
import { motion } from "framer-motion";
import { X, FileText, Building2, Paperclip, Clock, Activity, Receipt } from "lucide-react";
import type { InvoiceData } from "../../../types/invoice";
import InvoiceStatusBadge from "./status_badge";
import { formatCurrency } from "../../../lib/formatCurrency";
import InvoiceDetailsTab from "./details_tab";
import InvoiceVendorTab from "./vendor_tab";
import InvoiceFileTab from "./file_tab";
import InvoiceHistoryTab from "./history_tab";
import InvoiceStatusTab from "./status_tab";

type Tab = "details" | "vendor" | "file" | "history" | "status";

const tabs: { key: Tab; label: string; icon: React.ReactNode; color: string }[] = [
  { key: "details",  label: "Details",  icon: <FileText  className="w-3.5 h-3.5" />, color: "blue"    },
  { key: "vendor",   label: "Vendor",   icon: <Building2 className="w-3.5 h-3.5" />, color: "violet"  },
  { key: "file",     label: "File",     icon: <Paperclip className="w-3.5 h-3.5" />, color: "sky"     },
  { key: "history",  label: "History",  icon: <Clock     className="w-3.5 h-3.5" />, color: "amber"   },
  { key: "status",   label: "AI Result",icon: <Activity  className="w-3.5 h-3.5" />, color: "emerald" },
];

const tabActive: Record<string, string> = {
  blue:    "border-blue-500 text-blue-600 bg-blue-50",
  violet:  "border-violet-500 text-violet-600 bg-violet-50",
  sky:     "border-sky-500 text-sky-600 bg-sky-50",
  amber:   "border-amber-500 text-amber-600 bg-amber-50",
  emerald: "border-emerald-500 text-emerald-600 bg-emerald-50",
};

export default function InvoiceDetailPanel({ invoice, onClose }: { invoice: InvoiceData; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<Tab>("details");

  const activeColor = tabs.find(t => t.key === activeTab)?.color ?? "blue";
  const headerGradients: Record<string, string> = {
    blue:    "from-blue-500 to-blue-600",
    violet:  "from-violet-500 to-violet-600",
    sky:     "from-sky-500 to-sky-600",
    amber:   "from-amber-500 to-amber-600",
    emerald: "from-emerald-500 to-emerald-600",
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.2 }}
      className="flex flex-col h-full bg-white"
    >
      {/* Colorful Header */}
      <div className={`bg-linear-to-r ${headerGradients[activeColor]} p-5 shrink-0 transition-all duration-300`}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Receipt className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white font-mono tracking-tight">{invoice.invoice_id}</h2>
              <p className="text-xs text-white/80 mt-0.5 truncate max-w-48">{invoice.vendor.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
          >
            <X className="w-3.5 h-3.5 text-white" />
          </button>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-2xl font-bold text-white tabular-nums">
              {formatCurrency(invoice.total_amount, invoice.currency_code)}
            </p>
            <p className="text-xs text-white/70 mt-0.5">{invoice.invoice_date}</p>
          </div>
          <InvoiceStatusBadge status={invoice.status} />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 px-2 overflow-x-auto shrink-0 bg-white">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-1.5 px-3 py-3 text-xs font-semibold border-b-2 transition-all whitespace-nowrap rounded-t-lg mx-0.5 ${
              activeTab === tab.key
                ? tabActive[tab.color]
                : "border-transparent text-gray-400 hover:text-gray-600 hover:bg-gray-50"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto bg-gray-50/40">
        <div className="p-5">
          {activeTab === "details" && <InvoiceDetailsTab invoice={invoice} />}
          {activeTab === "vendor"  && <InvoiceVendorTab vendor={invoice.vendor} />}
          {activeTab === "file"    && <InvoiceFileTab fileUrl={invoice.file_url} />}
          {activeTab === "history" && <InvoiceHistoryTab invoiceId={invoice.invoice_id} />}
          {activeTab === "status"  && <InvoiceStatusTab invoiceId={invoice.invoice_id} />}
        </div>
      </div>
    </motion.div>
  );
}