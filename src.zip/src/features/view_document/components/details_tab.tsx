import { Calendar, Hash, CreditCard, Receipt, Tag, Clock } from "lucide-react";
import type { InvoiceData } from "../../../types/invoice";
import { formatCurrency } from "../../../lib/formatCurrency";

export default function InvoiceDetailsTab({ invoice }: { invoice: InvoiceData }) {
  const metaFields = [
    { icon: <Hash className="w-3.5 h-3.5" />, label: "Invoice ID",    value: invoice.invoice_id,    color: "text-blue-500",   bg: "bg-blue-50"   },
    { icon: <Receipt className="w-3.5 h-3.5" />, label: "PO Reference", value: invoice.po_id || "—", color: "text-violet-500", bg: "bg-violet-50" },
    { icon: <Calendar className="w-3.5 h-3.5" />, label: "Invoice Date", value: invoice.invoice_date, color: "text-sky-500",    bg: "bg-sky-50"    },
    { icon: <Clock className="w-3.5 h-3.5" />, label: "Due Date",     value: invoice.due_date,      color: "text-amber-500",  bg: "bg-amber-50"  },
    { icon: <CreditCard className="w-3.5 h-3.5" />, label: "Currency", value: invoice.currency_code, color: "text-emerald-500",bg: "bg-emerald-50"},
    { icon: <Tag className="w-3.5 h-3.5" />, label: "Status",        value: invoice.status,         color: "text-indigo-500", bg: "bg-indigo-50" },
  ];

  return (
    <div className="space-y-6">
      {/* Meta Fields */}
      <div>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Invoice Information</p>
        <div className="grid grid-cols-2 gap-3">
          {metaFields.map((f) => (
            <div key={f.label} className="bg-white rounded-xl border border-gray-100 p-3 shadow-sm">
              <div className={`inline-flex items-center gap-1.5 ${f.color} ${f.bg} px-2 py-1 rounded-lg mb-2`}>
                {f.icon}
                <span className="text-[11px] font-semibold">{f.label}</span>
              </div>
              <p className="text-sm font-bold text-gray-800 truncate capitalize">{f.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Line Items */}
      <div>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Line Items</p>
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-linear-to-r from-blue-50 to-blue-50/50 border-b border-blue-100">
                <th className="text-left px-3 py-2.5 text-xs font-bold text-blue-600">Description</th>
                <th className="text-right px-3 py-2.5 text-xs font-bold text-blue-600">Qty</th>
                <th className="text-right px-3 py-2.5 text-xs font-bold text-blue-600 hidden sm:table-cell">Rate</th>
                <th className="text-right px-3 py-2.5 text-xs font-bold text-blue-600">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.invoice_items.map((item, i) => (
                <tr key={i} className={`border-t border-gray-50 ${i % 2 === 1 ? "bg-gray-50/50" : ""}`}>
                  <td className="px-3 py-2.5 text-gray-700 text-xs">{item.item_description}</td>
                  <td className="px-3 py-2.5 text-right">
                    <span className="text-xs font-semibold text-gray-600 bg-gray-100 px-1.5 py-0.5 rounded-md">{item.quantity}</span>
                  </td>
                  <td className="px-3 py-2.5 text-right text-xs text-gray-500 hidden sm:table-cell">{item.unit_price ? formatCurrency(item.unit_price, invoice.currency_code) : "-"}</td>
                  <td className="px-3 py-2.5 text-right text-xs font-bold text-gray-800">{formatCurrency(item.total_price, invoice.currency_code)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Totals */}
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm">
        <div className="px-4 py-3 space-y-2.5">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Subtotal</span>
            <span className="font-semibold text-gray-700">{formatCurrency(invoice.subtotal, invoice.currency_code)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Tax</span>
            <span className="font-semibold text-orange-600">{formatCurrency(invoice.tax_amount, invoice.currency_code)}</span>
          </div>
          {invoice.discount_amount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Discount</span>
              <span className="font-semibold text-emerald-600">−{formatCurrency(invoice.discount_amount, invoice.currency_code)}</span>
            </div>
          )}
        </div>
        <div className="bg-linear-to-r from-blue-600 to-blue-700 px-4 py-3 flex justify-between items-center">
          <span className="text-sm font-bold text-white">Total Amount</span>
          <span className="text-lg font-bold text-white">{formatCurrency(invoice.total_amount, invoice.currency_code)}</span>
        </div>
      </div>
    </div>
  );
}